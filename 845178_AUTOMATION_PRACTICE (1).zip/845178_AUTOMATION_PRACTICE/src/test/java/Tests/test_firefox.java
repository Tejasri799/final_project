package Tests;

import org.testng.annotations.Test;

import BaseClass.Utilities;
import Excel.ExcelData;
import Pages.AmountInTheCart;
import Pages.HomePage;
import Pages.Profile_Page;
import Pages.Register_Page;
import Pages.SignUp_Page;

import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;

public class test_firefox extends ExcelData 	// directly importing ExcelData class......
{
	public static WebDriver dr;			
	Utilities ut;
	HomePage homepage;
	SignUp_Page signup;
	Register_Page register;
	Profile_Page profile;
	AmountInTheCart totalcost;
	// declaring all the pom pages and main class page as above...........
	String act_result;
	int counter=0;			//initializing an integer count variable for sreenshots method.......... 
  @Test(dataProvider = "dp")		//initializing test method using dataprovider.............
  public void Invalid_Registration(String email,String fname, String lname, String pwd, String ph, String a1, String ci, String zip, String a2,String exp_result) {
	  homepage=new HomePage(dr);		//initializing the register1 page..........
	  homepage.Enter();			//calling the register1 pom page for execution...........
	  signup=new SignUp_Page(dr);	// initializing the register2 page.........
	  signup.ToRegister(email);		//calling the register2 pom page for execution...........
	  register=new Register_Page(dr);		//initializing the register3 page...............
	  register.Registration(fname,lname,pwd,ph,a1,ci,zip,a2);	//calling the register3 pom page for execution...........
	   try {
	   profile=new Profile_Page(dr);		//initializing the register4 page..........
	   act_result = profile.Verify();	//calling the register4 pom page for execution...........
	 	 
	   }
	   catch(NullPointerException e)
	   {
		   act_result= register.error_mes();
		
	   }
	   ut.ScreenShot(counter);			//calling the screenshot method from utilities.............. 
	   System.out.println(act_result);		//printing the actual result(executed result)........
	   System.out.println(exp_result);		//printing the expected result.......
	   Assert.assertTrue(act_result.contains(exp_result));		//comparing both the above results..............

  }
  //UTTAM above test method ko 2 parts kardena mathlab @test dho aani chahiye 
  //1st priority = skip one mandatory field
  //and 
  //2nd @test method mein valid mandatoy fields...
  //since the mandatory fields will create an account and shopping can be done in that profile 
  //then we can have a good flow of execution of each class...
  
  @Test(priority=2)
  public void amount_in_cart(String total_price)
  {
	  totalcost = new AmountInTheCart(dr);
	  totalcost.AmountInCart(total_price);	//UTTAM yaha asssert daalke total amount compare karna hain
  }
  
  @BeforeMethod		//method for launching the firefox browser...............
  public void beforeMethod() {
	  ut = new Utilities(dr);
	  dr = ut.bb("firefox");

  }

  @AfterMethod				//method for closing the application after the execution..........
  public void afterMethod() {
	  dr.close();
	  counter++;
  }


  @DataProvider			//method for reading the data from excel to enter into the respective fields in the application using dataprovider..........
  public String[][] dp() {
	  getExcel("Sheet1");
	  return data;   
  }
}