package Tests;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BaseClass.Utilities;

import Pages.AmountInTheCart;
import Pages.HomePage;
import Pages.Profile_Page;
import Pages.Register_Page;
import Pages.SignUp_Page;
import excel.Read_excel;

import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;

public class test_chrome extends Read_excel {		// directly importing ExcelData class......
	public static WebDriver dr;			
	Utilities ut;
	HomePage homepage;
	SignUp_Page signup;
	Register_Page register;
	Profile_Page profile;
	AmountInTheCart totalcost;
	// declaring all the pom pages and main class page as above...........
	String act_result;
	int counter=0;	
	
	@Test(dataProvider = "invalid",priority=0)		//initializing test method using dataprovider.............
	  public void Invalid_Registration(String email,String fname, String lname, String pwd, String ph, String a1, String ci, String zip, String a2,String exp_result) {
		  homepage=new HomePage(dr);		//initializing the register1 page..........
		  homepage.Enter();			//calling the register1 pom page for execution...........
		  signup=new SignUp_Page(dr);	// initializing the register2 page.........
		  signup.ToRegister(email);		//calling the register2 pom page for execution...........
		  register=new Register_Page(dr);		//initializing the register3 page...............
		  register.Registration(fname,lname,pwd,ph,a1,ci,zip,a2);	//calling the register3 pom page for execution...........
		   act_result= register.error_mes();
		    ut.ScreenShot(counter);			//calling the screenshot method from utilities.............. 
		   System.out.println(act_result);		//printing the actual result(executed result)........
		   System.out.println(exp_result);		//printing the expected result.......
		   Assert.assertTrue(act_result.contains(exp_result));		//comparing both the above results..............

	  }
	  
	  @DataProvider			//method for reading the data from excel to enter into the respective fields in the application using dataprovider..........
	  public String[][] invalid() {
		  get_data("Sheet1",2,10);
		  return data;   
	  }
	
	

	 @Test(dataProvider = "valid",priority=1)		//initializing test method using dataprovider.............
	  public void Valid_Registration(String email,String fname, String lname, String pwd, String ph, String a1, String ci, String zip, String a2,String exp_result) {
		  homepage=new HomePage(dr);		//initializing the register1 page..........
		  homepage.Enter();			//calling the register1 pom page for execution...........
		  signup=new SignUp_Page(dr);	// initializing the register2 page.........
		  signup.ToRegister(email);		//calling the register2 pom page for execution...........
		  register=new Register_Page(dr);		//initializing the register3 page...............
		  register.Registration(fname,lname,pwd,ph,a1,ci,zip,a2);	//calling the register3 pom page for execution...........
		   profile=new Profile_Page(dr);		//initializing the register4 page..........
		   act_result = profile.Verify();	//calling the register4 pom page for execution...........
		 	ut.ScreenShot(counter);			//calling the screenshot method from utilities.............. 
		   System.out.println(act_result);		//printing the actual result(executed result)........
		   System.out.println(exp_result);		//printing the expected result.......
		   Assert.assertTrue(act_result.contains(exp_result));	//comparing both the above results..............

	  }
	  
	  @DataProvider			//method for providing data from excel by using data provider..........
	  public String[][] valid() {
		  get_data("Sheet1",4,10);
		  return data; 
		  
	  }
  
	  @Test(priority=2)
  public void amount_in_cart(String Exp_price)
  {
	  totalcost = new AmountInTheCart(dr);
	  String act_price = totalcost.AmountInCart(Exp_price);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(act_price,Exp_price);
	  sa.assertAll();	  
  }
    @BeforeMethod		//method for launching the chrome browser...............
  public void beforeMethod() {
	  ut = new Utilities(dr);
	  dr = ut.bb("Chrome");

  }

  @AfterMethod				//method for closing the application after the execution..........
  public void afterMethod() {
	  dr.close();
	  counter++;
  }
}


 
